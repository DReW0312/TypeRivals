import { initializeApp } from 'firebase/app'

const firebaseConfig = {
    apiKey: "AIzaSyASABZ7Ze_fFRhcuJIRytlD7tW4AQ85Vzo",
    authDomain: "typerivals-1f1ea.firebaseapp.com",
    projectId: "typerivals-1f1ea",
    storageBucket: "typerivals-1f1ea.firebasestorage.app",
    messagingSenderId: "860114967456",
    appId: "1:860114967456:web:08725f1939196558c7e2c5",
    measurementId: "G-P1RKM17XZ7"
  }

initializeApp(firebaseConfig)