import { initializeApp } from 'firebase/app'
import {
    getFirestore, collection, onSnapshot,
    addDoc,doc,
    query, where,
    orderBy, serverTimestamp,
    getDoc 
}from 'firebase/firestore'
import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword, signOut,
    onAuthStateChanged
}from 'firebase/auth'

const firebaseConfig = {
    apiKey: "AIzaSyASABZ7Ze_fFRhcuJIRytlD7tW4AQ85Vzo",
    authDomain: "typerivals-1f1ea.firebaseapp.com",
    projectId: "typerivals-1f1ea",
    storageBucket: "typerivals-1f1ea.firebasestorage.app",
    messagingSenderId: "860114967456",
    appId: "1:860114967456:web:08725f1939196558c7e2c5",
    measurementId: "G-P1RKM17XZ7"
  }

  // init firbase app
initializeApp(firebaseConfig)

// init services
const db = getFirestore()
const auth= getAuth()

// collection reference
const colRef = collection(db, 'Users')

// queries
const q = query(colRef, orderBy('createdAt'))

//real time collection data

onSnapshot(q, (snapshot) => {
    let User = []
    snapshot.docs.forEach((doc) => {
        User.push({ ...doc.data(), id:  doc.id  })
    })
    console.log(User)
})


// logging in and out
const logoutButton = document.querySelector('#logout')
logoutButton.addEventListener('click', () => {
    signOut(auth)
        .then(() => {
            console.log('User Signed out')
        })
        .catch((err) => {
            console.log(err.message )
        })
})