import { initializeApp } from 'firebase/app'
import {
    getFirestore, collection, onSnapshot,
    addDoc,doc,
    query, where,
    orderBy, serverTimestamp,
    getDoc 
}from 'firebase/firestore'
import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword, signOut,
    onAuthStateChanged
}from 'firebase/auth'

const firebaseConfig = {
    apiKey: "AIzaSyASABZ7Ze_fFRhcuJIRytlD7tW4AQ85Vzo",
    authDomain: "typerivals-1f1ea.firebaseapp.com",
    projectId: "typerivals-1f1ea",
    storageBucket: "typerivals-1f1ea.firebasestorage.app",
    messagingSenderId: "860114967456",
    appId: "1:860114967456:web:08725f1939196558c7e2c5",
    measurementId: "G-P1RKM17XZ7"
  }

  // init firbase app
initializeApp(firebaseConfig)

// init services
const db = getFirestore()
const auth= getAuth()

// collection reference
const colRef = collection(db, 'Users')

// queries
const q = query(colRef, orderBy('createdAt'))

//real time collection data

onSnapshot(q, (snapshot) => {
    let User = []
    snapshot.docs.forEach((doc) => {
        User.push({ ...doc.data(), id:  doc.id  })
    })
    console.log(User)
})


// signing users

const addUser = document.querySelector('.signup')
addUser.addEventListener('submit', (e) => {
    e.preventDefault()

    addDoc(colRef, {
        username: addUser.username.value,
        email: addUser.email.value,
        createdAt: serverTimestamp(),
    })
    .then(()=> {
        addUser.reset()
    })

    const email = addUser.email.value
    const password = addUser.password.value

    createUserWithEmailAndPassword(auth, email, password)
        .then((cred) => {
            console.log('User Created', cred.user);

            // Add user details to Firestore only after successful authentication
            return addDoc(colRef, {
                username: addUser.username.value,
                email: email,
                createdAt: serverTimestamp(),
            });
        })
        .then(() => {
            console.log('User Created', cred.user)
            
            window.location.href = './Login.html'
        })
        .catch((err) => {
            if (err.code === 'auth/email-already-in-use') {
                alert('User already exists. Redirecting to login page...')
            
                window.location.href = './Login.html'
            }
        })
}) 


